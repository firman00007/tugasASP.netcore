using FirstWebsite.pages.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Logging;


namespace FirstWebsite.Pages
{
    public class MahasiswaModel : PageModel
    {
        private readonly ILogger<MahasiswaModel> _logger;
        
        public MahasiswaModel(ILogger<MahasiswaModel> logger)
        {
            _logger = logger;
        }
        [BindProperty]
        public Mahasiswa Mhs {get;set;}
        public void OnGet()
        {

        }
        public IActionResult OnPost(){
            TempData["namaMahasiswa"]=Mhs.Nama;
            TempData["KelasMahasiswa"]=Mhs.Kelas;
            TempData["TempatLahir"]=Mhs.TempatLahir;
            TempData["tglMahasiswa"]=Mhs.TglLahir;
            TempData["tinggiMahasiswa"]=Mhs.tinggiBadan;
            TempData["hpMahasiswa"]=Mhs.Hp;
            return Page();
            
        }
    }
}